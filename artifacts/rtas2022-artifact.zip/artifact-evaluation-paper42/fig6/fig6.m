% Clean slate
clear variables;

% Read the data (acquired on the real process) from the csv file.
nom_30 = readmatrix('util/data/parsed_nom_30.csv');
ada_30 = readmatrix('util/data/parsed_ada_30.csv');
nom_50 = readmatrix('util/data/parsed_nom_50.csv');
ada_50 = readmatrix('util/data/parsed_ada_50.csv');

% Parse data
T = nom_30(:, 1); % Time
R = 15.*[zeros(floor(length(T)/2), 1); ones(ceil(length(T)/2), 1)]; % Reference
Y1_nom_30 = 5.*nom_30(:, 4); % transform voltage to length on beam
Y1_ada_30 = 5.*ada_30(:, 4); % transform voltage to length on beam
Y1_nom_50 = 5.*nom_50(:, 4); % transform voltage to length on beam
Y1_ada_50 = 5.*ada_50(:, 4); % transform voltage to length on beam

% Plot data
figure('Name', 'Figure 6', 'NumberTitle', 'off');
subplot(2, 2, 1)
plot(T, R, 'k');
hold on;
plot(T, Y1_nom_30, 'Color', [0,0.545,0]);
grid on;
ylabel('Output [cm]');
axis([500 550 -5, 20]);
yticks(0:5:15);
xticks(500:10:550);
yticklabels(0:5:15);
xticklabels([]);
title('rho = 30%')

subplot(2, 2, 2);
plot(T, R, 'k');
hold on;
plot(T, Y1_nom_50, 'Color', [0,0.545,0]);
grid on;
axis([500 550 -5, 20]);
yticks(0:5:15);
xticks([500:10:550]);
yticklabels([]);
xticklabels([]);
title('rho = 50%')

subplot(2, 2, 3);
plot(T, R, 'k');
hold on;
plot(T, Y1_ada_30, 'Color', [0.937,0.513,0.0627]);
grid on;
ylabel('Output [cm]');
xlabel('t [s]');
axis([500 550 -5, 20]);
yticks(0:5:15);
xticks(500:10:550);
yticklabels(0:5:15);
xticklabels(500:10:550);

subplot(2, 2, 4);
plot(T, R, 'k');
hold on;
plot(T, Y1_ada_50, 'Color', [0.937,0.513,0.0627]);
grid on;
xlabel('t [s]');
axis([500 550 -5, 20]);
yticks(0:5:15);
xticks(500:10:550);
yticklabels([]);
xticklabels(500:10:550);
