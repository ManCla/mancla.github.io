% Clean slate
clear variables;

% Helper parameters
T       = 0.01; % Sample time and control task's period
q_max   = 20;   % The maximum number of consecutive deadline misses

% Plant model
A = [1,     0.015,  0.0003375   0;
     0,     1,      0.045       0;
     0,     0,      1           0;
     0,     0,      0, 0.999999999];
B = [2.88e-05;
     0.00576;
     0.256;
     0];
C = [0.5, 0, 0,    -1;
     0,   0, 0.25, 0];
D = [0;
     0];
V = eye(4);

plant = ss(A, B, C, D, T);

% Controller - Cascaded P-PID
F = [1,          0;
     0,          0.9685];
G = [ 0.025,     0;
     -0.2608,    0];
H = [-0.108,    -0.2608];
K = [-2.43,     -3];

ctrler = ss(F, G, H, K, T);

% Classical control stability condition 
stab_poles = @(A) all(abs(eig(A)) < 1);

% Unstable  = jsr_lower_bound > 1
% Uncertain = jsr_lower_bound < 1 && jsr_upper_bound > 1
% Stable    = jsr_upper_bound < 1
helper_strings  = {'Unstable', 'Uncertain', 'Stable'};
to_string       = @(b) helper_strings{b+2};

% Results vectors
stab_nom = zeros(1, q_max);
stab_ada = zeros(1, q_max);

fprintf('BnB -> stable for 0 misses:       \t%s\n', to_string(stab_poles(generate_cl_matrix(plant, ctrler, false, 'NOM'))));

% Iterate stability for the Nominal control system
for q = q_max:-1:1 

    opts = jsrsettings('verbose', 0);

    % Construct the set of closed-loop matrices of which we are
    % going to determinte the switching stability
    sigma = {}; % the set of possibile matrices
    sigma{end+1} = generate_cl_matrix(plant, ctrler, false, 'NOM');
    for i = 1:q
        sigma{end+1} = generate_cl_matrix(plant, ctrler, false, 'NOM')*generate_cl_matrix(plant, ctrler, true)^i;
    end

    % calling jsr toolbox to get upper and lower bounds on the JSR
    jsr_bounds = jsr(sigma, opts);

    jsr_lower = jsr_bounds(1);
    jsr_upper = jsr_bounds(2);
    is_stable = jsr_upper < 1; % jsr_upper < 1 => Guaranteed Stable
    if jsr_lower > 1           % jsr_lower > 1 => Guaranteed unstable system
        is_stable = -1;
    end

    % Store result in vector and print it
    stab_nom(q) = is_stable;
    fprintf('    -> stable for %d misses (NOMINAL): \t%s\n', q, to_string(is_stable));

    % If it is stable, we know that all "easier to satisfy" systems are stable (Implication from [Vreman et al., 2021])
    if is_stable == 1
        stab_nom(1:q) = 1; % Implication from [Vreman et al., 2021]
        break;
    end
end

for q = q_max:-1:1

    opts = jsrsettings('verbose', 0);

    % Construct the set of closed-loop matrices of which we are
    % going to determinte the switching stability
    sigma = {}; % the set of possibile matrices
    sigma{end+1} = generate_cl_matrix(plant, ctrler, false, 'NOM');
    for i = 1:q
        sigma{end+1} = generate_cl_matrix(plant, ctrler, false, 'ADA', i)*generate_cl_matrix(plant, ctrler, true)^i;
    end

    % calling jsr toolbox to get upper and lower bounds on the JSR
    jsr_bounds = jsr(sigma, opts);

    jsr_lower = jsr_bounds(1);
    jsr_upper = jsr_bounds(2);
    is_stable = jsr_upper < 1;
    if jsr_lower > 1
        is_stable = -1;
    end

    % Store result in vector and print it
    stab_ada(q) = is_stable;
    fprintf('    -> stable for %d misses (ADAPTIVE): \t%s\n', q, to_string(is_stable));

    % If it is stable, we know that all "easier to satisfy" systems are stable (Implication from [Vreman et al., 2021])
    if is_stable == 1
        stab_ada(1:q) = 1;  % Implication from [Vreman et al., 2021]
        break;
    end
end

% Find number of consecutive deadline misses tolerated by the control systems
q_nom = find(stab_nom == 1, 1, 'last');
if isempty(q_nom) % system not stable 
    q_nom = 0;
end
q_ada = find(stab_ada == 1, 1, 'last');
if isempty(q_ada) % system not stable 
    q_ada = 0;
end
fprintf('Nominal control system guaranteed stable for at most q = %d consecutive deadline misses\n', q_nom)
fprintf('Adaptive control system guaranteed stable for at most q = %d consecutive deadline misses\n', q_ada)
