% Execute the stability analysis for the Ball and Beam
stability_bnb;

disp('--------------------------------------------------------------------------------------');

% Execute the stability analysis for the Benchmark Plants
stability_batch;
