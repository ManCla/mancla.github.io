% Clean slate
clear variables;

% Control and strategy types
ctrl_types = {'PI', 'PID'};
q_max      = 20;   % The maximum number of consecutive deadline misses

% Storage vectors
stab_nom = zeros(1, 268);
stab_ada = zeros(1, 268);
sys_ctr  = 0; % Counter variable

% Classical control stability condition 
stab_poles = @(A) all(abs(eig(A)) < 1);

% Unstable  = jsr_lower_bound > 1
% Uncertain = jsr_lower_bound < 1 && jsr_upper_bound > 1
% Stable    = jsr_upper_bound < 1
helper_strings  = {'Unstable', 'Uncertain', 'Stable'};
to_string       = @(b) helper_strings{b+2};

% start parallel iterating
for batch_id = 1:9

    % system batch
    batch = generate_batch(batch_id);

    % Get the number of systems in this batch
    n_ID = length(fieldnames(batch));

    % Iterate over all the different IDs in this batch
    for sys_id = 1:n_ID

        % Extract system with ID = sys_id
        sys = batch.(['ID', num2str(sys_id)]);

        % For each control type, iterate the system
        for ctrl_type_idx = 1:length(ctrl_types)
            ctrl_type = ctrl_types{ctrl_type_idx};

            % Increment system counter
            sys_ctr = sys_ctr + 1;
            
            % Extract system
            plant    = sys.plant;
            ctrler_c = sys.(ctrl_type);

            % Discretize according to bandwidth rule
            wb      = bandwidth(feedback(plant*ctrler_c, 1));
            T       = 0.1 / wb;
            ctrler  = -balreal(c2d(ctrler_c, T, 'foh'));
            plant   = balreal(c2d(plant, T));
            % Extend the system with a near-integrator state on the process
            % noise to acquire brownian noise instead of white noise.
            [A,B,C,D] = ssdata(plant);
            Ae = [0.999, zeros(1,size(A,2));
                  B, A];
            Be = [0; B];
            Ce = [0 C];
            plant = ss(Ae, Be, Ce, D, T);
            
            %%%%%%%%%%%
            %%% JSR %%%
            %%%%%%%%%%%

            sys_stab_nom = zeros(1, q_max);
            sys_stab_ada = zeros(1, q_max);

            fprintf('B%d-P%d-%s \t-> stable for 0 misses:             %s\n', ...
                batch_id, sys_id, ctrl_type, ...
                to_string(stab_poles(generate_cl_matrix(plant, ctrler, false, 'NOM'))));
            spaces = repmat(' ', 1, length(sprintf('B%d-P%d-%s ', batch_id, sys_id, ctrl_type)));
            for q = q_max:-1:1 % Iterate backwards because most systems are stable for q > q_{max} consecutive deadline misses
            
                opts = jsrsettings('verbose', 0);
            
                % Construct the set of closed-loop matrices of which we are
                % going to determinte the switching stability
                sigma = {}; % the set of possibile matrices
                sigma{end+1} = generate_cl_matrix(plant, ctrler, false, 'NOM');
                for i = 1:q
                    sigma{end+1} = generate_cl_matrix(plant, ctrler, false, 'NOM')*generate_cl_matrix(plant, ctrler, true)^i;
                end
            
                % calling jsr toolbox to get upper and lower bounds on the JSR
                jsr_bounds = jsr(sigma, opts);
            
                jsr_lower = jsr_bounds(1);
                jsr_upper = jsr_bounds(2);
                is_stable = jsr_upper < 1;  % jsr_upper < 1 => Guaranteed Stable
                if jsr_lower > 1            % jsr_lower > 1 => Guaranteed unstable system
                    is_stable = -1;
                end
            
                % Store result in vector and print it
                sys_stab_nom(q) = is_stable;
                fprintf('%s\t-> stable for %d misses (NOMINAL):  %s\n', spaces, q, to_string(is_stable));
            
                % If it is stable, we know that all "easier to satisfy" systems are stable (Implication from [Vreman et al., 2021])
                if is_stable == 1
                    sys_stab_nom(1:q) = 1; 
                    break;
                end
            end
            
            for q = q_max:-1:1

                opts = jsrsettings('verbose', 0);
            
                % Construct the set of closed-loop matrices of which we are
                % going to determinte the switching stability
                sigma = {}; % the set of possibile matrices
                sigma{end+1} = generate_cl_matrix(plant, ctrler, false, 'NOM');
                for i = 1:q
                    sigma{end+1} = generate_cl_matrix(plant, ctrler, false, 'ADA', i)*generate_cl_matrix(plant, ctrler, true)^i;
                end
            
                % calling jsr toolbox to get upper and lower bounds on the JSR
                jsr_bounds = jsr(sigma, opts);
            
                jsr_lower = jsr_bounds(1);
                jsr_upper = jsr_bounds(2);
                is_stable = jsr_upper < 1;  % jsr_upper < 1 => Guaranteed Stable
                if jsr_lower > 1            % jsr_lower > 1 => Guaranteed unstable system
                    is_stable = -1;
                end
            
                % Store result in vector and print it
                sys_stab_ada(q) = is_stable;
                fprintf('%s\t-> stable for %d misses (ADAPTIVE): %s\n', spaces, q, to_string(is_stable));
            
                % If it is stable, we know that all "easier to satisfy" systems are stable (Implication from [Vreman et al., 2021])
                if is_stable == 1
                    sys_stab_ada(1:q) = 1;  % Implication from [Vreman et al., 2021]
                    break;
                end
            end
            
            % Find number of consecutive deadline misses tolerated by the control systems
            q_nom = find(sys_stab_nom == 1, 1, 'last');
            if isempty(q_nom) % system not stable 
                q_nom = 0;
            end
            q_ada = find(sys_stab_ada == 1, 1, 'last');
            if isempty(q_ada) % system not stable 
                q_ada = 0;
            end

            % Update storage vectors
            stab_nom(sys_ctr) = q_nom;
            stab_ada(sys_ctr) = q_ada;
            disp(' ');
        end
    end
end

% Parse data
nom_data = zeros(1, q_max+1);
ada_data = zeros(1, q_max+1);
ctr = 1;
for i = 0:q_max
    nom_data(ctr) = nom_data(ctr) + sum(stab_nom == i);
    ada_data(ctr) = ada_data(ctr) + sum(stab_ada == i);
    ctr = ctr + 1;
end

% Print data
disp(' NUMBER OF SYSTEMS (OUT OF 268 IN TOTAL) THAT CAN TOLERATE UP  ');
disp(' TO q CONSECUTIVE DEADLINE MISSES WITHOUT RISKING INSTABILITY. ');
disp('---------------------------------------------------------------------');
fprintf(' \t q\t | \t C^n\t  \t C^a\n');
disp('---------------------------------------------------------------------');
for i = 0:q_max
    fprintf(' \t %d\t | \t %d\t  \t %d\n', i, nom_data(i+1), ada_data(i+1));
end
disp('---------------------------------------------------------------------');