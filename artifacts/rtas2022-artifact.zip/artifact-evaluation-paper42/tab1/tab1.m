% Clean slate
clear variables;

% Sample time
T = 0.01;

% Plant model
A = [1,     0.015,  0.0003375   0;
     0,     1,      0.045       0;
     0,     0,      1           0;
     0,     0,      0, 0.999999999];
B = [2.88e-05;
     0.00576;
     0.256;
     0];
C = [0.5, 0, 0,    -1;
     0,   0, 0.25, 0];
D = [0;
     0];
V = eye(4);

plant = ss(A, B, C, D, T);

% Controller - Cascaded P-PID
F = [1,          0;
     0,          0.9685];
G = [ 0.025,     0;
     -0.2608,    0];
H = [-0.108,    -0.2608];
K = [-2.43,     -3];

ctrler = ss(F, G, H, K, T);

% Analytic performance analysis
strat_types = {'NOM', 'ADA'};

% Miss constraint parameters
q_max       = 20;
max_iter    = 1000;
max_percent = 70;

% Extract lengths
nx = size(plant.A, 1);  % Number states plant
nu = size(plant.B, 2);  % Number inputs plant
ny = size(plant.C, 1);  % Number outputs plant
nz = size(ctrler.A, 1); % Number states controller
n  = nx+nz+ny+nu;       % Closed loop plant states

% Covariance matrix for closed loop
R1 = blkdiag(V*V', zeros(n-nx));

% Calculate nominal system, stationary covarianze, and cost
Phi_ideal = generate_cl_matrix(plant, ctrler, false, 'NOM', 0);
P_ideal   = dlyap(Phi_ideal, R1);
J_ideal   = trace(plant.C * P_ideal(1:nx, 1:nx) * plant.C');

% The miss matrix
Phi_miss = generate_cl_matrix(plant, ctrler, true);

% The combined hit/miss and covarianze matrices.
Phi_hit_three  = blkdiag(Phi_ideal, Phi_ideal, Phi_ideal);
Phi_miss_three = blkdiag(Phi_ideal, Phi_miss, Phi_miss);
R_three        = kron(ones(3, 3), R1); % G * R1 * G^T

% storage for results
perf = zeros(max_percent, length(strat_types));
for p_percent = 10:10:max_percent
    p = 0.01*p_percent;
    
    % For different number of misses, calculate A_tot and R_tot
    prob       = zeros(1, q_max+1);
    prob(1)    = 1-p;
    Phi_tot{1} = Phi_hit_three;
    R_tot{1}   = R_three;
    for q = 1:q_max
        prob(q+1)   = (1-p)*p^q;
        Phi_acc     = eye(size(Phi_hit_three));
        R_acc       = zeros(size(R_three));
        % q misses
        for k = 1:q
            Phi_acc = Phi_miss_three * Phi_acc;
            R_acc   = Phi_miss_three * R_acc * Phi_miss_three' + R_three;
        end
        % and one hit
        Phi_recov_three = blkdiag(Phi_ideal, ...
            generate_cl_matrix(plant, ctrler, false, strat_types{1}, q), ...
            generate_cl_matrix(plant, ctrler, false, strat_types{2}, q));
        Phi_acc      = Phi_recov_three * Phi_acc;
        R_acc        = Phi_recov_three * R_acc * Phi_recov_three' + R_three;
        Phi_tot{q+1} = Phi_acc;
        R_tot{q+1}   = R_acc;
    end
    
    prob(q_max+1) = 1 - sum(prob(1:q_max)); % Enforce a hit after q_max
    
    % Iterate to find stationary varianze in the "hit node"
    P = kron(ones(3, 3), P_ideal);
    for iter = 1:max_iter
        Pnext = zeros(size(R_three));
        for k = 1:q_max+1
            Pnext = Pnext + prob(k) * (Phi_tot{k} * P * Phi_tot{k}' + R_tot{k});
        end
        if trace(abs(P-Pnext)) < 1e-6 || trace(Pnext) > 1e10
            break
        end
        P = Pnext;
    end
    
    % W is the chanze to be in an interval of length idx at any
    % random time.
    W = (1:q_max+1) .* prob; % Weight for each interval
    W = W / sum(W); % How likely to be in each interval at any point in time
    
    Ccl         = [plant.C, zeros(ny, nz+ny+nu)];
    Cnom        = [Ccl,     0*Ccl,  0*Ccl]; % Output of ideal CL
    Cstrat{1}   = [0*Ccl,   Ccl,    0*Ccl]; % Output of nominal CL
    Cstrat{2}   = [0*Ccl,   0*Ccl,  Ccl];   % Output of adaptive CL
    for strat_idx = 1:2
        Cdiff = Cnom - Cstrat{strat_idx};   % Deviation from ideal output
        J_strat = 0;
        for k = 1:q_max+1
            Pint = P;     % Start with stationary varianze in "hit node"
            Jacc = 0;
            for l = 1:k   % Iterate k steps (misses) ahead add add upp cost
                Jacc = Jacc + trace(Cdiff * Pint * Cdiff');
                Pint = (Phi_miss_three * P * Phi_miss_three') + R_three;
            end
            J_strat = J_strat + W(k) * (Jacc / k);
        end
        perf(p_percent, strat_idx) = J_strat / J_ideal;
    end
end

% warn us if we for some reason perform worse.
if perf(:,2) > perf(:,1)
    warning('Adaptive worse than nominal in at least one point! :(')
end

% Parse data
perf = perf(~all(perf == 0, 2), :) .* 100;
% Print as table
disp('    RELATIVE PERFORMANCE DEGRADATION OF THE BALL AND BEAM PLANT');
disp('          USING EITHER THE NOMINAL OR ADAPTIVE CONTROLLER      ');
disp('                            [ANALYTIC]                         ');
disp('------------------------------------------------------------------');
fprintf('  rho  | 10%%\t| 20%%\t| 30%%\t| 40%%\t| 50%%\t| 60%%\t | 70%%\n');
disp('------------------------------------------------------------------');
fprintf('DJ^n/J | %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.0f%%\t | %3.0f%% \n', ...
    perf(1, 1), perf(2, 1), perf(3, 1), perf(4, 1), perf(5, 1), perf(6, 1), perf(7, 1));
fprintf('DJ^a/J | %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t | %3.1f%% \n', ...
    perf(1, 2), perf(2, 2), perf(3, 2), perf(4, 2), perf(5, 2), perf(6, 2), perf(7, 2));
disp('------------------------------------------------------------------');
