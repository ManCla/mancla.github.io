function batch = generate_batch(batch_id)
%GENERATE_BATCH

batches = load('batches.mat');
if strcmpi(batch_id, 'VARIABLES')
    batch = batches.variables;
else
    batch = batches.(['P', num2str(batch_id)]);
end

end

