function Phi = generate_cl_matrix(plant, ctrler, miss, mode, q)
%GENERATE_CL_MATRIX
% Returns the closed-loop system matrix depending on if the current
% deadline was hit or missed (miss), which controller is used (mode),
% and how many previous deadline misses that has been experienced (q).

if miss
    Phi = sys_mat_miss(plant, ctrler);
else
    if strcmpi(mode, 'ADA')
        Phi = sys_mat_ada(plant, ctrler, q);
    elseif strcmpi(mode, 'NOM')
        Phi = sys_mat_nom(plant, ctrler);
    else
        error('No idea what is happening');
    end
end

end

%% Aux functions

function Phi_miss = sys_mat_miss(plant, ctrler)
% Returns the closed loop system matrix for the extended state  
% [x_k, z_k, y_{k-1}, u_k] when missing the deadline of the ctrler

% Extract necessary data
[A, B, C, D, ~] = ssdata(plant);
[F, G, H, K, ~] = ssdata(ctrler);

nx = size(A, 1);
nu = size(B, 2);
ny = size(C, 1);
nz = size(F, 1);
   
% System expression
Phi_miss = [A_x(A, 0),    zeros(nx, nz),  zeros(nx, ny),  B_x(A, B, 0);
        zeros(nz, nx),    eye(nz),        zeros(nz, ny),  zeros(nz, nu);
        zeros(ny, nx),    zeros(ny, nz),  eye(ny),        zeros(ny, nu);
        zeros(nu, nx),    zeros(nu, nz),  zeros(nu, ny),  eye(nu)];
end

function Phi_nom = sys_mat_nom(plant, ctrler)
% Returns the closed loop system matrix for the extended state  
% [x_k, z_k, y_{k-1}, u_k] evolved q time steps into the future, using nominal
% dynamics

% Extract necessary data
[A, B, C, D, ~] = ssdata(plant);
[F, G, H, K, ~] = ssdata(ctrler);

nx = size(A, 1);
nu = size(B, 2);
ny = size(C, 1);
nz = size(F, 1);
   
% System expression
Phi_nom = [A_x(A, 0), zeros(nx, nz),  zeros(nx, ny),  B_x(A, B, 0);
        G*C,          F,              zeros(nz, ny),  G*D;
        C,            zeros(ny, nz),  zeros(ny),      D;
        K*C,          H,              zeros(nu, ny),  K*D];
end

function Phi_ada = sys_mat_ada(plant, ctrler, q)
% Returns the closed loop system matrix for the extended state  
% [x_k, z_k, y_{k-1}, u_k] evolved q time steps into the future, using adaptive
% dynamics

% Extract necessary data
[A, B, C, D, ~] = ssdata(plant);
[F, G, H, K, ~] = ssdata(ctrler);

nx = size(A, 1);
nu = size(B, 2);
ny = size(C, 1);
nz = size(F, 1);
   
% System expression
Phi_ada = [A_x(A, 0),         zeros(nx, nz),  zeros(nx, ny),      B_x(A, B, 0);
        G_y(F, G, q)*C,       F_z(F, q),      F_y(F, G, q),       G_y(F, G, q)*D;
        C,                    zeros(ny, nz),  zeros(ny),          D;
        K_y(F, G, H, K, q)*C, H_z(F, H, q),   H_y(F, G, H, q),    K_y(F, G, H, K, q)*D];
end

%% Auxiliary functions

function mat = A_x(A, q)
% Return Phi_y
mat = A^(q+1);
end

function mat = B_x(A, B, q)
% Return Phi_y
mat = zeros(size(A*B));
for i = 0:q
    mat = mat + A^i*B;
end
end

function mat = F_z(F, q)
% Return Phi_y
mat = F^(q+1);
end

function mat = F_y(F, G, q)
% Return Phi_y
mat = zeros(size(F*G));
for i = 0:q
    mat = mat + (i/(q+1))*F^i*G;
end
end

function mat = G_y(F, G, q)
% Return Phi_y
mat = zeros(size(F*G));
for i = 0:q
    mat = mat + ((q+1-i)/(q+1))*F^i*G;
end
end

function mat = H_z(F, H, q)
% Return Phi_y
mat = H*F^(q);
end

function mat = H_y(F, G, H, q)
% Return Phi_y
mat = zeros(size(H*F*G));
for i = 1:q
    mat = mat + H*(i/(q+1))*F^(i-1)*G;
end
end

function mat = K_y(F, G, H, K, q)
% Return Phi_y
mat = K;
for i = 1:q
    mat = mat + H*((q+1-i)/(q+1))*F^(i-1)*G;
end
end
