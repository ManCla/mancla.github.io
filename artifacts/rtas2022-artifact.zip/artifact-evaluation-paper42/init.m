% Clean slate
clear all;
close all;

% Add paths to figure folders 
addpath(genpath('fig2'));
addpath(genpath('fig3'));
addpath(genpath('fig5'));
addpath(genpath('fig6'));
addpath(genpath('fig7'));
addpath(genpath('tab1'));
addpath(genpath('tab2'));
addpath(genpath('fig8'));
addpath(genpath('util'));
