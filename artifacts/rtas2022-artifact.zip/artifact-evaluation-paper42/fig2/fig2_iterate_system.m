function [X_ideal, X_miss] = fig2_iterate_system(plant, ctrler, T_miss, max_itr) 
% FIG2_ITERATE_SYSTEM
%   Iterates the control system consisting of 'plant' and 'ctrler' (using
%   positive feedback convention). Both the results under ideal conditions
%   (i.e., no deadline misses) and subject to misses at the discrete time points
%   specified in 'T_miss' are returned.

% Extract sample time
T = plant.Ts;

% Extract lengths
nx  = size(plant.A, 1);     % Number states plant
nu  = size(plant.B, 2);     % Number inputs plant
ny  = size(plant.C, 1);     % Number outputs plant
nz  = size(ctrler.A, 1);    % Number states controller

% Initialise closed-loop state
x0      = [ones(nx, 1); zeros(nz, 1); zeros(ny, 1); zeros(nu, 1)]; % Impulse disturbance at time 0
x_ideal = x0;
x_miss  = x0;

% Storage variables
T_vec   = cumsum(T*ones(1, max_itr));
X_ideal = zeros(length(x_ideal), max_itr);
X_miss  = zeros(length(x_miss), max_itr);

miss_ctr = 1;
% Iterate system in time
for i = 1:max_itr
    
    % Generates a miss or a hit according to T_miss
    miss = (abs(T_vec(i) - T_miss(miss_ctr)) < eps);
    if miss
        miss_ctr = miss_ctr + 1;
    end
    
    % Generate closed-loop system matrix depending on whether it was a deadline
    % hit or miss.
    A_ideal = generate_cl_matrix(plant, ctrler, false, 'NOM');
    A_miss  = generate_cl_matrix(plant, ctrler, miss, 'NOM');
    
    % Evolve state
    x_ideal = A_ideal * x_ideal;
    x_miss  = A_miss * x_miss;

    % Store data
    X_ideal(:, i)   = x_ideal;
    X_miss(:, i)    = x_miss;
end

% Prepend initial state to stored data.
X_ideal = [x0, X_ideal];
X_miss  = [x0, X_miss];
end
