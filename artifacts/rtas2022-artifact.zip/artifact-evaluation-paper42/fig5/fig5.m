% Clean slate
clear variables;

% Read the parsed data (acquired on the real process) from the csv file.
data = readmatrix('util/data/parsed_ideal.csv');

% Parse data
t = data(:, 1); % Time
R = 15.*[zeros(floor(length(t)/2), 1); ones(ceil(length(t)/2), 1)]; % Reference
Y1 = 5.*data(:, 4); % transform voltage to length (on beam)

% Plot figure
figure('Name', 'Figure 5', 'NumberTitle', 'off');
plot(t, R, 'k');
hold on;
plot(t, Y1, 'Color', [0,0.11,1]); 
grid on;
xlabel('t [s]');
ylabel('Output [cm]');
axis([500 550 -5, 20]);
yticks(0:5:15);
xticks(500:10:550);
