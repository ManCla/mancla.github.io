% Clean slate
clear variables;

% Helper parameter initialisation
q_max          = 20;
miss_prob_vec  = 0.1:0.1:0.7;
idx_first      = 3000; % The idx of the data matrices where the experiments start

% path variable
path        = [pwd '/util/data'];

% Ideal results acquired on the physical plant (used as the comparative baseline)
file_names  = dir(sprintf('%s/experiment_Mode_1.csv', path)); % get the ideal experiment data
fn_ideal    = [path, '/', file_names.name]; 	              % Extracting the relevant file
T_ideal     = readtable(fn_ideal);

% Extracting the ideal data
exp_e_ideal = [T_ideal.E1(idx_first:end), T_ideal.E2(idx_first:end)];

Q       = [1, 2]; % The measurements to include in the cost (i.e., both measurements)
J_ideal = var( sum( exp_e_ideal(:, Q).^2, 2) ); % Calculate the stationary variance for the ideal system

% performance over different miss probabilities
perf    = zeros(length(miss_prob_vec), 2);
max_dev = zeros(length(miss_prob_vec), 2);
for miss_prob = miss_prob_vec

    %%%%%%%%%%%
    % Nominal %
    %%%%%%%%%%%

    % We know that the last file doesn't exist (because the nominal control system became unstable for miss_prob == 0.7)
    if abs(miss_prob - 0.7) < eps
        perf(round(miss_prob*10), 1)    = Inf;
        max_dev(round(miss_prob*10), 1) = Inf;
    else
        % Get the nominal results acquired on the physical plant
        file_names  = dir(sprintf('%s/experiment_M_%d_P_%d_Mode_2.csv', ...
            path, ...
            q_max, ...
            round(miss_prob*100)));          % Finding all files in folder with the current path
        fn_nominal  = [path, '/', file_names.name]; 	% Extracting the relevant file
        T_nominal   = readtable(fn_nominal);
        
        % Extracting data
        exp_e_nominal = [T_nominal.E1(idx_first:end), T_nominal.E2(idx_first:end)];
    
        % Computing the nominal controller's relative performance and maximum deviation
        J_nom_diff                      = var( sum( (exp_e_ideal(:, Q) - exp_e_nominal(:, Q)).^2, 2) );
        perf(round(miss_prob*10), 1)    = J_nom_diff / J_ideal;
        % Computing maximum ball position deviation
        max_dev(round(miss_prob*10), 1) = max( abs(exp_e_ideal(:, 1) - exp_e_nominal(:, 1)) );
    end
    
    %%%%%%%%%%%%
    % Adaptive %
    %%%%%%%%%%%%

    % Get the adaptive results acquired on the physical plant
    file_names  = dir(sprintf('%s/experiment_M_%d_P_%d_Mode_3.csv', ...
        path, ...
        q_max, ...
        round(miss_prob*100)));          % Finding all files in folder with the current path
    fn_adaptive = [path, '/', file_names.name]; 	% Extracting the relevant file
    T_adaptive  = readtable(fn_adaptive);
    
    % Extracting data
    exp_e_adaptive = [T_adaptive.E1(idx_first:end), T_adaptive.E2(idx_first:end)];
    
    % Computing the adaptive controller's relative performance and maximum deviation
    J_ada_diff                      = var( sum( (exp_e_ideal(:, Q) - exp_e_adaptive(:, Q)).^2, 2) );
    perf(round(miss_prob*10), 2)    = J_ada_diff / J_ideal;
    % Computing maximum ball position deviation
    max_dev(round(miss_prob*10), 2) = max( abs(exp_e_ideal(:, 1) - exp_e_adaptive(:, 1)) );

end

% Parse data and print as table
perf = perf .* 100;
disp('    RELATIVE PERFORMANCE DEGRADATION OF THE BALL AND BEAM PLANT');
disp('          USING EITHER THE NOMINAL OR ADAPTIVE CONTROLLER      ');
disp('                            [PHYSICAL]                         ');
disp('------------------------------------------------------------------');
fprintf('  rho  | 10%%\t| 20%%\t| 30%%\t| 40%%\t| 50%%\t| 60%%\t | 70%%\n');
disp('------------------------------------------------------------------');
fprintf('DJ^n/J | %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%% | %3.1f%% \n', ...
    perf(1, 1), perf(2, 1), perf(3, 1), perf(4, 1), perf(5, 1), perf(6, 1), perf(7, 1));
fprintf('DJ^a/J | %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t| %3.1f%%\t | %3.1f%% \n', ...
    perf(1, 2), perf(2, 2), perf(3, 2), perf(4, 2), perf(5, 2), perf(6, 2), perf(7, 2));
disp('------------------------------------------------------------------');
