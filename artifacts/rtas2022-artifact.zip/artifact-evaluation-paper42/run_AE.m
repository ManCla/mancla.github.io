% INTRODUCTION:
% This script can be run to generate all the results presented in the paper. 
% * In order for the switching stability to be runnable, SEDUMI has to be
%   installed.
% * In order for more or less all the other files to be run, the Control System
%   Toolbox has to be installed.
% * If you want to use the "readmatrix" function for fig5, fi6, and tab2, you
%   need to use Matlab R2019a or later. 

% Initialise paths and folders
init;

% Run the motivating example (Section III-B)
disp('Generating Figure 2...');
fig2;

% Run the continuation of the motivating example (Section IV-A)
disp('Generating Figure 3...');
fig3;

% Run to generate a figure depicting 1 snippet of the data acquired from the
% physical plant run with the IDEAL controller (Section V-A) 
disp('Generating Figure 5...');
fig5;

% Run to generate a figure depicting 4 snippet of the data acquired from the
% physical plant run with either the NOMINAL or ADAPTIVE controllers for 
% \rho = 30% or \rho = 50% deadline misses (Section V-A) 
disp('Generating Figure 6...');
fig6;

% Run relative performance degradation tests on the benchmark evaluation using
% both the NOMINAL and ADAPTIVE controllers for \rho \in {10%, 30%, 50%, 70%}
% deadline misses. Generates the corresponding plot (Section V-B) 
disp('Generating Figure 7...');
fig7;

% Run relative performance degradation on the analytical model of the ball and
% beam for \rho \in {10%, 20%, ..., 70%} deadline misses. Generates the
% corresponding table (Section V-A).
disp('Generating Table 1...');
tab1;

% Run to generate a table containing the relative performance degradation for
% the NOMINAL and ADAPTIVE controllers run on the physical plant for 
% \rho \in {10%, 20%, ..., 70%} deadline misses (Section V-A).
disp('Generating Table 2...');
tab2;

% Run to generate a table containing the number of switching stable control
% systems in the benchmark evaluation. Each column represent how many control
% systems could tolerate $q$ consecutive deadline misses for both the NOMINAL
% and ADAPTIVE controllers subject to 
% \rho \in {10%, 30%, 50%, 70%} deadline misses (Section V-B).
disp('Generating data of Figure 8...');
fig8;
