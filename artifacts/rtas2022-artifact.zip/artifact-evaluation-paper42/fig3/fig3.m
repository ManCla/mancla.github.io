% Clean slate
clear variables;

% Sample time
T = 0.1;

% Plant model
A = [ 0,   1; 
     -0.8, 1.8];
B = [ 0; 
      1];
C = eye(2);
D = [ 0; 
      0];

plant = ss(A, B, C, D, T);

% Controller - LQG
F = [-0.1507,  0.81;
     -0.7105,  1.206];
G = [ 0.1507,  0.19;
      0.166,   0.2214];
H = [ 0.2259, -0.2418];
K = [-0.0233, -0.0338];

ctrl = ss(F, G, H, K, T);

% help variables for function
max_itr = 50;
T_miss = [0.3, 0.7, 0.9, 1.6, 2.1, 2.2, 2.3, 2.9, 3.2, 3.5, 3.8, 4.1, 5.0];

% Simulate system using an initial impulse disturbance.
[X_ideal, X_miss_nom]   = fig3_iterate_system(plant, ctrl, 'NOM', T_miss, max_itr);
[~, X_miss_ada]         = fig3_iterate_system(plant, ctrl, 'ADA', T_miss, max_itr);
t                       = 0:T:max_itr*T;

% Parse and plot
figure('Name', 'Figure 3', 'NumberTitle', 'off');
hold on; grid on;
plot(t, X_miss_nom(2, :), '-.', 'LineWidth', 2, 'Color', [0,0.545,0]);
plot(t, X_ideal(2, :), 'LineWidth', 2, 'Color', [0,0.545,0]);
plot(t, X_miss_ada(2, :), '--', 'LineWidth', 2, 'Color', [0.937,0.513,0.0627]);

misses = -0.4 * ones(length(T_miss), 1);
plot(T_miss, misses, 'xr', 'LineWidth', 3, 'MarkerSize', 10);

legend({'x_2 (C2^a - adaptive)', 'x_2 (C2^n - nominal)', 'x_2 (C2 - ideal)', 'Overrun'})
