% Clean slate
clear variables;

% Control and strategy types
ctrl_types = {'PI', 'PID'};
strat_types = {'NOM', 'ADA'};

% Miss constraint parameters
max_misses  = 20;
max_iter    = 1000;
max_percent = 70;

rel_perf_10 = zeros(2, 268);
rel_perf_30 = zeros(2, 268);
rel_perf_50 = zeros(2, 268);
rel_perf_70 = zeros(2, 268);

sys_ctr = 0;

% start iterating
for batch_id = 1:9
    
    % system batch
    batch = generate_batch(batch_id);
    
    % Get the number of systems in this batch
    n_ID = length(fieldnames(batch));
    
    % Iterate over all the different IDs in this batch
    for sys_id = 1:n_ID
        
        % Extract system with ID = sys_id
        sys = batch.(['ID', num2str(sys_id)]);
        
        % For each control type, iterate the system
        for ctrl_type_idx = 1:length(ctrl_types)
            ctrl_type = ctrl_types{ctrl_type_idx};
            sys_ctr = sys_ctr+1;
            fprintf('Batch %d - Sys %d: %s\n', batch_id, sys_id, ctrl_type);
            
            % Extract system
            plant    = sys.plant;
            ctrler_c = sys.(ctrl_type);
            
            % Discretize according to bandwidth rule
            wb      = bandwidth(feedback(plant*ctrler_c, 1));
            T       = 0.1 / wb;
            ctrler  = -balreal(c2d(ctrler_c, T, 'foh'));
            plant   = balreal(c2d(plant, T));
            % Extend the system with a near-integrator state on the process
            % noise to acquire brownian noise instead of white noise.
            [A,B,C,D] = ssdata(plant);
            Ae = [0.999, zeros(1,size(A,2));
                  B, A];
            Be = [0; B];
            Ce = [0 C];
            plant = ss(Ae, Be, Ce, D, T);
            
            % Extract lengths
            nx = size(plant.A, 1);  % Number states plant
            nu = size(plant.B, 2);  % Number inputs plant
            ny = size(C, 1);        % Number outputs plant
            nz = size(ctrler.A, 1); % Number states controller
            n  = nx+nz+ny+nu;
            
            R1 = zeros(n);
            R1(1,1) = 1;
            
            % Calculate nominal system, stationary covariance, and cost
            Phi_ideal = generate_cl_matrix(plant, ctrler, false, 'NOM', 0);
            P_ideal = dlyap(Phi_ideal, R1);
            J_ideal = plant.C * P_ideal(1:nx, 1:nx) * plant.C';
            
            % storage for results
            perf = zeros(max_percent, length(strat_types));
            for p_percent = 10:20:max_percent
                p = 0.01*p_percent;
                
                % For different number of misses, calculate Phi_tot and R_tot
                Phi_miss = generate_cl_matrix(plant, ctrler, true);

                Phi_hit_three  = blkdiag(Phi_ideal, Phi_ideal, Phi_ideal);
                Phi_miss_three = blkdiag(Phi_ideal, Phi_miss, Phi_miss);
                R_three        = kron(ones(3, 3), R1);
          
                prob       = zeros(1,max_misses+1); 
                prob(1)    = 1-p;
                Phi_tot{1} = Phi_hit_three;
                R_tot{1}   = R_three;
                for q = 1:max_misses
                    prob(q+1) = (1-p)*p^q;
                    Phi_acc   = eye(size(Phi_hit_three));
                    R_acc     = zeros(size(R_three));
                    % q misses
                    for k = 1:q
                        Phi_acc = Phi_miss_three * Phi_acc;
                        R_acc   = Phi_miss_three * R_acc * Phi_miss_three' + R_three;
                    end
                    % and one hit
                    Phi_recov_three = blkdiag(Phi_ideal, ...
                        generate_cl_matrix(plant, ctrler, false, strat_types{1}, q), ...
                        generate_cl_matrix(plant, ctrler, false, strat_types{2}, q));
                    Phi_acc      = Phi_recov_three * Phi_acc;
                    R_acc        = Phi_recov_three * R_acc * Phi_recov_three' + R_three;
                    Phi_tot{q+1} = Phi_acc;
                    R_tot{q+1}   = R_acc;
                end
                
                prob(max_misses+1) = 1-sum(prob(1:max_misses)); % Enforce a hit after max_misses
                 
                % Iterate to find stationary variance
                P = kron(ones(3, 3), P_ideal);
                for iter = 1:max_iter
                    Pnext = zeros(size(R_three));
                    for k = 1:max_misses+1
                        Pnext = Pnext + prob(k) * (Phi_tot{k} * P * Phi_tot{k}' + R_tot{k});
                    end
                    if trace(abs(P-Pnext)) < 1e-3 || trace(Pnext) > 1e10
                        break
                    end
                    P = Pnext;
                end
                
                % Get relative performance
                Ccl       = [plant.C zeros(1,nz+ny+nu)];
                Cideal    = [Ccl,   0*Ccl, 0*Ccl];      % Output of ideal CL
                Cstrat{1} = [0*Ccl, Ccl,   0*Ccl];      % Output of nominal CL 
                Cstrat{2} = [0*Ccl, 0*Ccl, Ccl];        % Output of adaptive CL
                for strat_idx = 1:2
                    Cdiff   = Cideal - Cstrat{strat_idx};     % Deviation from ideal output
                    J_strat = (Cdiff * P * Cdiff') / J_ideal; % Mean-square deviation ideal relative to J_ideal

                    % Store results
                    if abs(p_percent - 10) < eps
                        rel_perf_10(strat_idx, sys_ctr) = J_strat;
                    elseif abs(p_percent - 30) < eps
                        rel_perf_30(strat_idx, sys_ctr) = J_strat;
                    elseif abs(p_percent - 50) < eps
                        rel_perf_50(strat_idx, sys_ctr) = J_strat;
                    else
                        rel_perf_70(strat_idx, sys_ctr) = J_strat;
                    end
                end
            end
        end
    end
end

% Parse data
rel_perf_10_log = log10(rel_perf_10);
rel_perf_30_log = log10(rel_perf_30);
rel_perf_50_log = log10(rel_perf_50);
rel_perf_70_log = log10(rel_perf_70);

rel_perf_50_log(rel_perf_50_log > 1) = log10(150);
rel_perf_70_log(rel_perf_70_log > 1) = log10(150);

% Plot data:
n_bins = 65;
edges = (-5:(2.2-(-5))/n_bins:2.2);
x_axis = [-5, log10(200)];
y_axis = [0, 160];
x_line = [2, 2];
y_line = y_axis;

figure('Name', 'Figure 7', 'NumberTitle', 'off');
subplot(4, 1, 1);
histogram(rel_perf_10_log(1, :), edges, 'FaceColor', [0,0.545,0]);
grid on; hold on;
histogram(rel_perf_10_log(2, :), edges, 'FaceColor', [0.937,0.513,0.0627]);
axis([x_axis y_axis]);
line(x_line, y_line, 'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
yticks(0:50:150);
xticks(-5:1:2);
yticklabels(0:50:150);
xticklabels({'1e-5' '1e-4' '1e-3' '1e-2' '1e-1' '1e0' '1e1' 'Inf'});
set(gca, 'XScale', 'lin');

subplot(4, 1, 2);
histogram(rel_perf_30_log(1, :), edges, 'FaceColor', [0,0.545,0]);
grid on; hold on;
histogram(rel_perf_30_log(2, :), edges, 'FaceColor', [0.937,0.513,0.0627]);
axis([x_axis y_axis]);
line(x_line, y_line, 'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
yticks(0:50:150);
xticks(-5:1:2);
yticklabels(0:50:150);
xticklabels({'1e-5' '1e-4' '1e-3' '1e-2' '1e-1' '1e0' '1e1' 'Inf'});
set(gca, 'XScale', 'lin');

subplot(4, 1, 3);
histogram(rel_perf_50_log(1, :), edges, 'FaceColor', [0,0.545,0]);
grid on; hold on;
histogram(rel_perf_50_log(2, :), edges, 'FaceColor', [0.937,0.513,0.0627]);
axis([x_axis y_axis]);
line(x_line, y_line, 'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
yticks(0:50:150);
xticks(-5:1:2);
yticklabels(0:50:150);
xticklabels({'1e-5' '1e-4' '1e-3' '1e-2' '1e-1' '1e0' '1e1' 'Inf'});
set(gca, 'XScale', 'lin');

subplot(4, 1, 4);
histogram(rel_perf_70_log(1, :), edges, 'FaceColor', [0,0.545,0]);
grid on; hold on;
histogram(rel_perf_70_log(2, :), edges, 'FaceColor', [0.937,0.513,0.0627]);
axis([x_axis y_axis]);
line(x_line, y_line, 'Color', 'r', 'LineStyle', '--', 'LineWidth', 2);
yticks(0:50:150);
xticks(-5:1:2);
yticklabels(0:50:150);
xticklabels({'1e-5' '1e-4' '1e-3' '1e-2' '1e-1' '1e0' '1e1' 'Inf'});
set(gca, 'XScale', 'lin');
